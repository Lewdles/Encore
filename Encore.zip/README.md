# Encore

A native SwiftUI player for your own Spotify Premium account: Home, Library,
Search, album / playlist / artist pages, a mini player and a full-screen
Now Playing view.

Encore signs in with Spotify's official login (Authorization Code + PKCE) and
talks to the official Spotify Web API. It does not contain any Spotify code.
Audio is played by the Spotify app on your phone (or any other Spotify Connect
device); Encore is the screen and the remote.

## What you need

- Spotify Premium (required by Spotify for Development Mode apps and for playback control)
- The Spotify app installed on the iPhone
- A free GitHub account (its cloud Mac compiles the app, so you don't need a Mac)
- Your usual way of sideloading an IPA

## 1. Create your Spotify app (once)

1. Go to https://developer.spotify.com/dashboard and log in.
2. Create an app. Any name and description will do.
3. Redirect URI: `encore-player://callback` (exactly like this).
4. Under "Which API/SDKs are you planning to use?" tick **Web API**.
5. Save, open the app's settings and copy the **Client ID**.

If Encore later says your user is not registered, open the app's
**User Management** tab in the dashboard and add your Spotify account's email.

## 2. Build the IPA on GitHub

1. Create a new repository (public or private).
2. Upload `Encore.zip` to it: **Add file → Upload files → Commit changes**.
3. **Add file → Create new file**, name it `.github/workflows/build.yml`,
   paste the contents of the `build.yml` file you were given, and commit.
4. Open the **Actions** tab. The "Build IPA" run takes a few minutes.
5. When it turns green, open **Releases** and download `Encore.ipa`.
   (It is also attached to the run as the `Encore-ipa` artifact.)

To rebuild after a change, upload the new `Encore.zip` over the old one.

If the run turns red, open it: the compiler errors are listed at the top of
the run summary. Send them over and they can be fixed.

## 3. Install and sign in

1. Sign and install `Encore.ipa` with your sideloading tool.
2. Open Encore, paste your Client ID, tap **Log In with Spotify**.
3. Approve access on Spotify's page.

## Lyrics

Spotify does not share lyrics with third-party apps. The lyrics button in the
player loads them from LRCLIB (https://lrclib.net), a free community database.
Time-synced lyrics follow the song and you can tap a line to jump to it; some
songs only have plain text, and some have none.

## Good to know

- If nothing plays, open the Spotify app once and come back. Spotify only
  accepts remote commands while its app is awake.
- Spotify's Development Mode limits: search returns at most 10 results per
  type, and track lists are only available for playlists you own or
  collaborate on (other playlists still play).
- Spotify signs apps out after six months; just log in again.
- Bundle ID: `app.encore.player`. Change it in `project.yml` if your signing
  setup needs a different one.

## Project layout

- `Sources/` Swift source (SwiftUI, iOS 17+)
- `Resources/Assets.xcassets` app icon and accent colour
- `project.yml` XcodeGen project description
- `.github/workflows/build.yml` the cloud build

Encore is not affiliated with Spotify. Spotify is a trademark of Spotify AB.
