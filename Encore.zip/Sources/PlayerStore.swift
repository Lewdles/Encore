import Combine
import Foundation
import SwiftUI
import UIKit

struct Toast: Equatable {
    let text: String
    let offersSpotify: Bool
}

/// Mirrors what Spotify is playing and sends playback commands.
/// The Spotify app does the actual audio; Encore is the screen and the remote.
@MainActor
final class PlayerStore: ObservableObject {
    typealias Command = (String?) async throws -> Void

    @Published private(set) var playback: SPPlayback?
    @Published var progressMs: Double = 0
    @Published private(set) var isLiked: Bool = false
    @Published private(set) var toast: Toast?
    @Published var showNowPlaying: Bool = false
    @Published private(set) var devices: [SPDevice] = []
    @Published private(set) var isLoadingDevices: Bool = false

    let api: SpotifyAPI

    private var pollTask: Task<Void, Never>?
    private var toastTask: Task<Void, Never>?
    private var isScrubbing: Bool = false
    private var holdProgressUntil: Date = Date.distantPast
    private var pendingCommand: Command?
    private var pendingSince: Date = Date.distantPast
    private var pollPausedUntil: Date = Date.distantPast
    private var endRefreshURI: String?

    init(api: SpotifyAPI) {
        self.api = api
    }

    // MARK: Derived state

    var track: SPTrack? {
        playback?.item
    }

    var isPlaying: Bool {
        playback?.isPlaying ?? false
    }

    var durationMs: Double {
        Double(playback?.item?.durationMs ?? 0)
    }

    var shuffleOn: Bool {
        playback?.shuffleState ?? false
    }

    var repeatMode: String {
        playback?.repeatState ?? "off"
    }

    var activeDeviceName: String? {
        playback?.device?.name
    }

    var activeDeviceID: String? {
        playback?.device?.id
    }

    // MARK: Lifecycle

    func becameActive() {
        start()
        guard let command = pendingCommand else { return }
        pendingCommand = nil
        // Only resume a tap that happened moments ago, e.g. right before opening Spotify.
        guard Date().timeIntervalSince(pendingSince) < 120 else { return }
        Task {
            try? await Task.sleep(nanoseconds: 800_000_000)
            await self.run(command)
        }
    }

    func start() {
        guard pollTask == nil else { return }
        pollTask = Task { [weak self] in
            var tick = 0
            while !Task.isCancelled {
                guard let store = self else { return }
                // Ask Spotify only every few seconds; the progress bar ticks locally in between.
                let interval = store.isPlaying ? 5 : 12
                if tick % interval == 0 {
                    await store.refresh()
                } else {
                    store.advanceLocally()
                }
                tick += 1
                try? await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }
    }

    func stop() {
        pollTask?.cancel()
        pollTask = nil
    }

    func reset() {
        stop()
        playback = nil
        progressMs = 0
        isLiked = false
        devices = []
        pendingCommand = nil
        toast = nil
        showNowPlaying = false
    }

    // MARK: Syncing with Spotify

    func refresh() async {
        if Date() < pollPausedUntil {
            return
        }
        do {
            let state = try await api.playback()
            apply(state)
        } catch let apiError as APIError {
            // Background polling stays quiet; commands report their own errors.
            if apiError.isRateLimited {
                pollPausedUntil = Date().addingTimeInterval(45)
            }
        } catch {
            // Offline or cancelled: try again on the next tick.
        }
    }

    private func apply(_ state: SPPlayback?) {
        let previousURI = playback?.item?.uri
        let newURI = state?.item?.uri
        playback = state
        let trackChanged = newURI != previousURI
        if trackChanged {
            endRefreshURI = nil
            isLiked = false
            progressMs = Double(state?.progressMs ?? 0)
            if let uri = newURI, uri.hasPrefix("spotify:track:") {
                Task { await self.checkLiked(uri) }
            }
        } else if !isScrubbing && Date() > holdProgressUntil {
            progressMs = Double(state?.progressMs ?? 0)
        }
    }

    private func advanceLocally() {
        guard isPlaying, !isScrubbing else { return }
        let duration = durationMs
        guard duration > 0 else { return }
        progressMs = min(progressMs + 1000, duration)
        // At the end of a track, check once for the next one instead of waiting for the next poll.
        if progressMs >= duration, let uri = playback?.item?.uri, endRefreshURI != uri {
            endRefreshURI = uri
            Task {
                try? await Task.sleep(nanoseconds: 1_200_000_000)
                await self.refresh()
            }
        }
    }

    private func refreshSoon() async {
        try? await Task.sleep(nanoseconds: 500_000_000)
        await refresh()
    }

    private func checkLiked(_ uri: String) async {
        let saved = (try? await api.isSaved(uri: uri)) ?? false
        if playback?.item?.uri == uri {
            isLiked = saved
        }
    }

    // MARK: Running commands

    /// Runs a playback command. If Spotify has no active device, retries on one that is available.
    @discardableResult
    private func run(_ command: @escaping Command) async -> Bool {
        var succeeded = false
        do {
            try await command(nil)
            succeeded = true
        } catch let apiError as APIError where apiError.isNoActiveDevice {
            succeeded = await retryOnAvailableDevice(command)
        } catch {
            show(error)
        }
        await refreshSoon()
        return succeeded
    }

    private func retryOnAvailableDevice(_ command: @escaping Command) async -> Bool {
        do {
            let found = try await api.devices()
            devices = found
            if let deviceID = preferredDevice(in: found)?.id {
                try await command(deviceID)
                return true
            }
            pendingCommand = command
            pendingSince = Date()
            showToast("Spotify isn't awake on any device. Open it once, then come back.", offersSpotify: true)
            return false
        } catch {
            show(error)
            return false
        }
    }

    private func preferredDevice(in list: [SPDevice]) -> SPDevice? {
        let usable = list.filter { $0.id != nil && $0.isRestricted != true }
        if let active = usable.first(where: { $0.isActive == true }) {
            return active
        }
        if let phone = usable.first(where: { ($0.type ?? "").lowercased() == "smartphone" }) {
            return phone
        }
        return usable.first
    }

    // MARK: Toasts

    func show(_ error: Error) {
        if isCancellation(error) { return }
        showToast(describe(error), offersSpotify: false)
    }

    func showToast(_ text: String, offersSpotify: Bool) {
        toast = Toast(text: text, offersSpotify: offersSpotify)
        toastTask?.cancel()
        let seconds: UInt64 = offersSpotify ? 9 : 4
        toastTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: seconds * 1_000_000_000)
            if Task.isCancelled { return }
            self?.toast = nil
        }
    }

    func openSpotify() {
        guard let url = URL(string: "spotify://") else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    // MARK: Starting playback

    /// Plays an album, playlist or artist, optionally starting at one of its tracks.
    func play(contextURI: String, trackURI: String?) {
        var draft: [String: Any] = ["context_uri": contextURI]
        if let trackURI {
            draft["offset"] = ["uri": trackURI]
        }
        let body = draft
        let api = self.api
        holdProgressUntil = Date().addingTimeInterval(1.5)
        Task {
            await self.run { deviceID in
                try await api.play(deviceID: deviceID, body: body)
            }
        }
    }

    /// Starts an album or playlist on a random track with shuffle switched on.
    func playShuffled(contextURI: String) {
        let body: [String: Any] = ["context_uri": contextURI]
        let api = self.api
        Task {
            await self.run { deviceID in
                try? await api.setShuffle(true, deviceID: deviceID)
                try await api.play(deviceID: deviceID, body: body)
                try? await api.setShuffle(true, deviceID: deviceID)
                try? await api.skipNext(deviceID: deviceID)
            }
        }
    }

    /// Plays a loose list of tracks (search results, liked songs) from the tapped one onward.
    func play(tracks: [SPTrack], startAt index: Int) {
        guard index >= 0, index < tracks.count else { return }
        let remaining = tracks[index...].compactMap { $0.isPlayable ? $0.uri : nil }
        let uris = Array(remaining.prefix(100))
        guard !uris.isEmpty else {
            showToast("This item can't be played from here.", offersSpotify: false)
            return
        }
        let body: [String: Any] = ["uris": uris]
        let api = self.api
        holdProgressUntil = Date().addingTimeInterval(1.5)
        Task {
            await self.run { deviceID in
                try await api.play(deviceID: deviceID, body: body)
            }
        }
    }

    // MARK: Transport

    func togglePlayPause() {
        let wasPlaying = isPlaying
        playback?.isPlaying = !wasPlaying
        holdProgressUntil = Date().addingTimeInterval(1.5)
        let api = self.api
        Task {
            await self.run { deviceID in
                if wasPlaying {
                    try await api.pause(deviceID: deviceID)
                } else {
                    try await api.play(deviceID: deviceID, body: nil)
                }
            }
        }
    }

    func skipNext() {
        let api = self.api
        Task {
            await self.run { deviceID in
                try await api.skipNext(deviceID: deviceID)
            }
        }
    }

    func skipPrevious() {
        let api = self.api
        Task {
            await self.run { deviceID in
                try await api.skipPrevious(deviceID: deviceID)
            }
        }
    }

    func beginScrub() {
        isScrubbing = true
    }

    func endScrub() {
        let target = Int(progressMs)
        isScrubbing = false
        holdProgressUntil = Date().addingTimeInterval(2)
        let api = self.api
        Task {
            await self.run { deviceID in
                try await api.seek(toMs: target, deviceID: deviceID)
            }
        }
    }

    func toggleShuffle() {
        let newValue = !shuffleOn
        playback?.shuffleState = newValue
        let api = self.api
        Task {
            await self.run { deviceID in
                try await api.setShuffle(newValue, deviceID: deviceID)
            }
        }
    }

    func cycleRepeat() {
        let nextMode: String
        switch repeatMode {
        case "off":
            nextMode = "context"
        case "context":
            nextMode = "track"
        default:
            nextMode = "off"
        }
        playback?.repeatState = nextMode
        let api = self.api
        Task {
            await self.run { deviceID in
                try await api.setRepeat(nextMode, deviceID: deviceID)
            }
        }
    }

    func addToQueue(uri: String) {
        let api = self.api
        Task {
            let added = await self.run { deviceID in
                try await api.addToQueue(uri: uri, deviceID: deviceID)
            }
            if added {
                self.showToast("Added to queue", offersSpotify: false)
            }
        }
    }

    // MARK: Liked songs

    func toggleLike() {
        guard let uri = track?.uri, uri.hasPrefix("spotify:track:") else { return }
        let newValue = !isLiked
        isLiked = newValue
        let api = self.api
        Task {
            do {
                if newValue {
                    try await api.saveToLibrary(uri: uri)
                } else {
                    try await api.removeFromLibrary(uri: uri)
                }
            } catch {
                if self.track?.uri == uri {
                    self.isLiked = !newValue
                }
                self.show(error)
            }
        }
    }

    // MARK: Devices

    func loadDevices() async {
        isLoadingDevices = true
        do {
            devices = try await api.devices()
        } catch {
            show(error)
        }
        isLoadingDevices = false
    }

    func transfer(to device: SPDevice) {
        guard let deviceID = device.id else { return }
        let api = self.api
        Task {
            do {
                try await api.transfer(to: deviceID, play: true)
                await self.refreshSoon()
                await self.loadDevices()
            } catch {
                self.show(error)
            }
        }
    }
}
