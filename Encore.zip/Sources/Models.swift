import Foundation

// Every field is optional on purpose. Spotify trimmed and renamed several
// fields for Development Mode apps in 2026, and one missing field should
// never stop a whole screen from loading.

struct SPImage: Decodable, Hashable {
    let url: String?
    let width: Int?
    let height: Int?
}

struct SPArtist: Decodable, Hashable {
    let id: String?
    let name: String?
    let uri: String?
    let images: [SPImage]?
    let genres: [String]?
}

struct SPAlbum: Decodable, Hashable {
    let id: String?
    let name: String?
    let uri: String?
    let albumType: String?
    let totalTracks: Int?
    let releaseDate: String?
    let images: [SPImage]?
    let artists: [SPArtist]?
}

struct SPAlbumFull: Decodable, Hashable {
    let id: String?
    let name: String?
    let uri: String?
    let albumType: String?
    let totalTracks: Int?
    let releaseDate: String?
    let images: [SPImage]?
    let artists: [SPArtist]?
    let tracks: SPPage<SPTrack>?
}

struct SPTrack: Decodable, Hashable {
    let id: String?
    let name: String?
    let uri: String?
    let durationMs: Int?
    let explicit: Bool?
    let trackNumber: Int?
    let isLocal: Bool?
    let type: String?
    let artists: [SPArtist]?
    let album: SPAlbum?
    let images: [SPImage]?
}

extension SPTrack {
    var title: String {
        name ?? "Unknown"
    }

    var artistLine: String {
        (artists ?? []).compactMap { $0.name }.joined(separator: ", ")
    }

    var artworkImages: [SPImage]? {
        album?.images ?? images
    }

    var isPlayable: Bool {
        uri != nil && isLocal != true
    }
}

struct SPPage<Item: Decodable & Hashable>: Decodable, Hashable {
    let items: [Item?]?
    let next: String?
    let total: Int?

    var list: [Item] {
        (items ?? []).compactMap { $0 }
    }
}

struct SPOwner: Decodable, Hashable {
    let id: String?
    let displayName: String?
}

/// One row of a playlist. Spotify renamed `track` to `item` in 2026, so both are read.
struct SPPlaylistEntry: Decodable, Hashable {
    let resolved: SPTrack?

    private enum CodingKeys: String, CodingKey {
        case item
        case track
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let newer = try? container.decodeIfPresent(SPTrack.self, forKey: .item)
        let older = try? container.decodeIfPresent(SPTrack.self, forKey: .track)
        resolved = newer ?? older
    }
}

struct SPPlaylistItems: Decodable, Hashable {
    let total: Int?
    let next: String?
    let items: [SPPlaylistEntry?]?

    var tracks: [SPTrack] {
        (items ?? []).compactMap { $0?.resolved }
    }
}

struct SPPlaylist: Decodable, Hashable {
    let id: String?
    let name: String?
    let uri: String?
    let images: [SPImage]?
    let owner: SPOwner?
    /// Track list. Spotify renamed `tracks` to `items` in 2026, so both are read.
    let content: SPPlaylistItems?

    private enum CodingKeys: String, CodingKey {
        case id
        case name
        case uri
        case images
        case owner
        case items
        case tracks
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try? container.decodeIfPresent(String.self, forKey: .id)
        name = try? container.decodeIfPresent(String.self, forKey: .name)
        uri = try? container.decodeIfPresent(String.self, forKey: .uri)
        images = try? container.decodeIfPresent([SPImage].self, forKey: .images)
        owner = try? container.decodeIfPresent(SPOwner.self, forKey: .owner)
        let newer = try? container.decodeIfPresent(SPPlaylistItems.self, forKey: .items)
        let older = try? container.decodeIfPresent(SPPlaylistItems.self, forKey: .tracks)
        content = newer ?? older
    }
}

struct SPSavedTrack: Decodable, Hashable {
    let track: SPTrack?
}

struct SPSavedAlbum: Decodable, Hashable {
    let album: SPAlbum?
}

struct SPPlayHistory: Decodable, Hashable {
    let track: SPTrack?
}

struct SPFollowing: Decodable {
    let artists: SPPage<SPArtist>?
}

struct SPSearch: Decodable {
    let tracks: SPPage<SPTrack>?
    let albums: SPPage<SPAlbum>?
    let artists: SPPage<SPArtist>?
    let playlists: SPPage<SPPlaylist>?
}

struct SPUser: Decodable {
    let id: String?
    let displayName: String?
}

struct SPDevice: Decodable, Hashable {
    let id: String?
    let name: String?
    let type: String?
    let isActive: Bool?
    let isRestricted: Bool?
}

struct SPDeviceList: Decodable {
    let devices: [SPDevice?]?
}

struct SPContext: Decodable, Hashable {
    let uri: String?
    let type: String?
}

struct SPPlayback: Decodable, Hashable {
    var device: SPDevice?
    var shuffleState: Bool?
    var repeatState: String?
    var progressMs: Int?
    var isPlaying: Bool?
    var item: SPTrack?
    var context: SPContext?
}

struct SPQueue: Decodable {
    let currentlyPlaying: SPTrack?
    let queue: [SPTrack?]?
}

struct SPErrorEnvelope: Decodable {
    struct Body: Decodable {
        let status: Int?
        let message: String?
        let reason: String?
    }

    let error: Body?
}

struct TokenResponse: Decodable {
    let accessToken: String
    let expiresIn: Int?
    let refreshToken: String?
}

struct TokenErrorBody: Decodable {
    let error: String?
    let errorDescription: String?
}

// MARK: - Small helpers

/// Spotify lists artwork in several sizes. Pick the smallest one that is still sharp enough.
func artworkURL(_ images: [SPImage]?, minWidth: Int) -> URL? {
    guard let images, !images.isEmpty else { return nil }
    let bigEnough = images.filter { ($0.width ?? 0) >= minWidth }
    let smallestBigEnough = bigEnough.min { ($0.width ?? 0) < ($1.width ?? 0) }
    let chosen = smallestBigEnough ?? images.first
    guard let text = chosen?.url else { return nil }
    return URL(string: text)
}

func formatTime(ms: Double) -> String {
    let totalSeconds = max(0, Int(ms / 1000))
    let minutes = totalSeconds / 60
    let seconds = totalSeconds % 60
    return String(format: "%d:%02d", minutes, seconds)
}

func describe(_ error: Error) -> String {
    if let localized = error as? LocalizedError, let text = localized.errorDescription {
        return text
    }
    return error.localizedDescription
}

func isCancellation(_ error: Error) -> Bool {
    if error is CancellationError {
        return true
    }
    if let urlError = error as? URLError, urlError.code == .cancelled {
        return true
    }
    return false
}
