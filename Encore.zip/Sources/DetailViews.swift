import SwiftUI

struct AlbumView: View {
    let albumID: String

    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore

    @State private var album: SPAlbumFull?
    @State private var tracks: [SPTrack] = []
    @State private var errorText: String?

    var body: some View {
        ScrollView {
            if let album {
                VStack(spacing: 0) {
                    DetailHeader(
                        imageURL: artworkURL(album.images, minWidth: 600),
                        title: album.name ?? "Album",
                        subtitle: artistNames(album),
                        caption: caption(album),
                        onPlay: {
                            if let uri = album.uri {
                                player.play(contextURI: uri, trackURI: nil)
                            }
                        },
                        onShuffle: {
                            if let uri = album.uri {
                                player.playShuffled(contextURI: uri)
                            }
                        }
                    )
                    artistLink(album)
                    trackList(album)
                }
            } else if let errorText {
                LoadFailedView(message: errorText) {
                    Task { await load() }
                }
            } else {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .padding(.top, 120)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if album == nil {
                await load()
            }
        }
    }

    @ViewBuilder private func artistLink(_ album: SPAlbumFull) -> some View {
        if let artist = album.artists?.first, let id = artist.id {
            NavigationLink(value: Route.artist(id)) {
                Label("More by " + (artist.name ?? "this artist"), systemImage: "person.circle")
                    .font(.subheadline)
            }
            .padding(.bottom, 12)
        }
    }

    private func trackList(_ album: SPAlbumFull) -> some View {
        VStack(spacing: 0) {
            ForEach(Array(tracks.enumerated()), id: \.offset) { index, track in
                TrackButton(track: track, number: track.trackNumber ?? (index + 1), showArtwork: false) {
                    if let albumURI = album.uri {
                        player.play(contextURI: albumURI, trackURI: track.uri)
                    }
                }
                Divider()
            }
        }
        .padding(.horizontal, 20)
    }

    private func artistNames(_ album: SPAlbumFull) -> String {
        (album.artists ?? []).compactMap { $0.name }.joined(separator: ", ")
    }

    private func caption(_ album: SPAlbumFull) -> String {
        var parts: [String] = []
        if let kind = album.albumType {
            parts.append(kind.capitalized)
        }
        if let date = album.releaseDate, date.count >= 4 {
            parts.append(String(date.prefix(4)))
        }
        let count = album.totalTracks ?? tracks.count
        if count > 0 {
            parts.append(count == 1 ? "1 song" : "\(count) songs")
        }
        return parts.joined(separator: " · ")
    }

    private func load() async {
        errorText = nil
        do {
            let loaded = try await api.album(id: albumID)
            var all = loaded.tracks?.list ?? []
            if let next = loaded.tracks?.next {
                let more = (try? await api.moreAlbumTracks(from: next)) ?? []
                all.append(contentsOf: more)
            }
            tracks = all
            album = loaded
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
            }
        }
    }
}

struct PlaylistView: View {
    let playlistID: String

    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore

    @State private var playlist: SPPlaylist?
    @State private var tracks: [SPTrack] = []
    @State private var errorText: String?

    var body: some View {
        ScrollView {
            if let playlist {
                VStack(spacing: 0) {
                    DetailHeader(
                        imageURL: artworkURL(playlist.images, minWidth: 600),
                        title: playlist.name ?? "Playlist",
                        subtitle: playlist.owner?.displayName ?? "",
                        caption: caption(playlist),
                        onPlay: {
                            if let uri = playlist.uri {
                                player.play(contextURI: uri, trackURI: nil)
                            }
                        },
                        onShuffle: {
                            if let uri = playlist.uri {
                                player.playShuffled(contextURI: uri)
                            }
                        }
                    )
                    if tracks.isEmpty {
                        Text("Spotify only shares the track list of playlists you own or collaborate on. You can still press Play.")
                            .font(.subheadline)
                            .foregroundStyle(Color.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 32)
                            .padding(.top, 8)
                    } else {
                        trackList(playlist)
                    }
                }
            } else if let errorText {
                LoadFailedView(message: errorText) {
                    Task { await load() }
                }
            } else {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .padding(.top, 120)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if playlist == nil {
                await load()
            }
        }
    }

    private func trackList(_ playlist: SPPlaylist) -> some View {
        VStack(spacing: 0) {
            ForEach(Array(tracks.enumerated()), id: \.offset) { _, track in
                TrackButton(track: track) {
                    if let playlistURI = playlist.uri {
                        player.play(contextURI: playlistURI, trackURI: track.uri)
                    }
                }
                Divider()
            }
        }
        .padding(.horizontal, 20)
    }

    private func caption(_ playlist: SPPlaylist) -> String {
        let count = playlist.content?.total ?? tracks.count
        if count <= 0 {
            return "Playlist"
        }
        return count == 1 ? "1 song" : "\(count) songs"
    }

    private func load() async {
        errorText = nil
        do {
            let loaded = try await api.playlist(id: playlistID)
            var all = loaded.content?.tracks ?? []
            if let next = loaded.content?.next {
                let more = (try? await api.morePlaylistTracks(from: next)) ?? []
                all.append(contentsOf: more)
            }
            tracks = all
            playlist = loaded
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
            }
        }
    }
}

struct ArtistView: View {
    let artistID: String

    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore

    @State private var artist: SPArtist?
    @State private var albums: [SPAlbum] = []
    @State private var errorText: String?

    private let columns: [GridItem] = [
        GridItem(.flexible(), spacing: 16, alignment: .top),
        GridItem(.flexible(), spacing: 16, alignment: .top)
    ]

    var body: some View {
        ScrollView {
            if let artist {
                VStack(spacing: 24) {
                    header(artist)
                    if !albums.isEmpty {
                        SectionHeader(title: "Albums and Singles")
                        LazyVGrid(columns: columns, spacing: 20) {
                            ForEach(Array(albums.enumerated()), id: \.offset) { _, album in
                                if let id = album.id {
                                    NavigationLink(value: Route.album(id)) {
                                        GridCard(
                                            title: album.name ?? "Album",
                                            subtitle: albumCaption(album),
                                            imageURL: artworkURL(album.images, minWidth: 300)
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                }
                .padding(.bottom, 24)
            } else if let errorText {
                LoadFailedView(message: errorText) {
                    Task { await load() }
                }
            } else {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .padding(.top, 120)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if artist == nil {
                await load()
            }
        }
    }

    private func header(_ artist: SPArtist) -> some View {
        VStack(spacing: 14) {
            Artwork(url: artworkURL(artist.images, minWidth: 300), size: 190, isCircle: true)
                .shadow(color: Color.black.opacity(0.2), radius: 14, x: 0, y: 8)
            Text(artist.name ?? "Artist")
                .font(.largeTitle.bold())
                .multilineTextAlignment(.center)
            Button {
                if let uri = artist.uri {
                    player.play(contextURI: uri, trackURI: nil)
                }
            } label: {
                Label("Play", systemImage: "play.fill")
                    .font(.headline)
                    .padding(.horizontal, 28)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
    }

    private func albumCaption(_ album: SPAlbum) -> String {
        var parts: [String] = []
        if let date = album.releaseDate, date.count >= 4 {
            parts.append(String(date.prefix(4)))
        }
        if let kind = album.albumType {
            parts.append(kind.capitalized)
        }
        return parts.joined(separator: " · ")
    }

    private func load() async {
        errorText = nil
        do {
            let loaded = try await api.artist(id: artistID)
            artist = loaded
            albums = (try? await api.artistAlbums(id: artistID)) ?? []
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
            }
        }
    }
}
