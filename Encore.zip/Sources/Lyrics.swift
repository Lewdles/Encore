import Combine
import Foundation
import SwiftUI

// Spotify does not share lyrics with third-party apps, so they come from LRCLIB
// (https://lrclib.net), a free community lyrics database. Matching is by title,
// artist, album and length, so some songs will have no lyrics or imperfect ones.

struct LyricLine: Hashable {
    let timeMs: Double
    let text: String
}

enum LyricsState: Equatable {
    case idle
    case loading
    case synced([LyricLine])
    case plain([String])
    case instrumental
    case notFound
    case failed(String)
}

struct LRCLibRecord: Decodable {
    let duration: Double?
    let instrumental: Bool?
    let plainLyrics: String?
    let syncedLyrics: String?
}

@MainActor
final class LyricsStore: ObservableObject {
    @Published private(set) var state: LyricsState = .idle

    private var loadedURI: String?
    private var cache: [String: LyricsState] = [:]
    private let session: URLSession

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 12
        configuration.httpAdditionalHeaders = ["User-Agent": "Encore/1.0 (personal iOS music remote)"]
        session = URLSession(configuration: configuration)
    }

    func reset() {
        loadedURI = nil
        state = .idle
    }

    /// Loads lyrics for the given track unless they are already showing.
    func load(for track: SPTrack?) async {
        guard let track else {
            reset()
            return
        }
        guard let uri = track.uri, uri.hasPrefix("spotify:track:") else {
            loadedURI = nil
            state = .notFound
            return
        }
        if loadedURI == uri && state != .idle && state != .loading {
            return
        }
        if let cached = cache[uri] {
            loadedURI = uri
            state = cached
            return
        }
        loadedURI = uri
        state = .loading
        let result = await fetch(track)
        guard loadedURI == uri else {
            return
        }
        if Task.isCancelled {
            reset()
            return
        }
        state = result
        if case .failed = result {
            return
        }
        if cache.count > 60 {
            cache.removeAll()
        }
        cache[uri] = result
    }

    // MARK: Fetching

    private func fetch(_ track: SPTrack) async -> LyricsState {
        let title = track.name ?? ""
        let artist = track.artists?.first?.name ?? ""
        let album = track.album?.name ?? ""
        let seconds = Double(track.durationMs ?? 0) / 1000
        guard !title.isEmpty, !artist.isEmpty else {
            return .notFound
        }
        do {
            var exactQuery: [String: String] = [
                "track_name": title,
                "artist_name": artist,
                "duration": String(Int(seconds.rounded()))
            ]
            if !album.isEmpty {
                exactQuery["album_name"] = album
            }
            if let exact = try await request("/api/get", query: exactQuery, returning: LRCLibRecord.self) {
                let found = LyricsStore.makeState(from: exact)
                if found != .notFound {
                    return found
                }
            }
            let searchQuery: [String: String] = [
                "track_name": LyricsStore.cleanTitle(title),
                "artist_name": artist
            ]
            let candidates = try await request("/api/search", query: searchQuery, returning: [LRCLibRecord].self) ?? []
            return LyricsStore.bestState(from: candidates, seconds: seconds)
        } catch {
            return .failed("Couldn't load lyrics. Check your connection and try again.")
        }
    }

    private func request<Value: Decodable>(_ path: String, query: [String: String], returning type: Value.Type) async throws -> Value? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "lrclib.net"
        components.path = path
        var items: [URLQueryItem] = []
        for name in query.keys.sorted() {
            items.append(URLQueryItem(name: name, value: query[name]))
        }
        components.queryItems = items
        // URLComponents leaves "+" alone, but servers read it as a space.
        if let encoded = components.percentEncodedQuery {
            components.percentEncodedQuery = encoded.replacingOccurrences(of: "+", with: "%2B")
        }
        guard let url = components.url else {
            return nil
        }
        let (data, response) = try await session.data(from: url)
        guard let http = response as? HTTPURLResponse else {
            return nil
        }
        if http.statusCode == 404 {
            return nil
        }
        guard http.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        return try? JSONDecoder().decode(Value.self, from: data)
    }

    // MARK: Choosing and parsing

    private static func makeState(from record: LRCLibRecord) -> LyricsState {
        if let synced = record.syncedLyrics {
            let lines = parseSynced(synced)
            if !lines.isEmpty {
                return .synced(lines)
            }
        }
        if let plain = record.plainLyrics {
            let lines = plainLines(plain)
            if !lines.isEmpty {
                return .plain(lines)
            }
        }
        if record.instrumental == true {
            return .instrumental
        }
        return .notFound
    }

    /// Prefers time-synced lyrics from a recording of the same length. A recording of a
    /// different length would have the wrong timings, so only its plain text is used.
    private static func bestState(from records: [LRCLibRecord], seconds: Double) -> LyricsState {
        let sameLength = records.filter { record in
            guard let duration = record.duration else { return false }
            return abs(duration - seconds) <= 3
        }
        for record in sameLength {
            let candidate = makeState(from: record)
            if case .synced = candidate {
                return candidate
            }
        }
        for record in sameLength {
            let candidate = makeState(from: record)
            if candidate != .notFound {
                return candidate
            }
        }
        for record in records {
            if let plain = record.plainLyrics {
                let lines = plainLines(plain)
                if !lines.isEmpty {
                    return .plain(lines)
                }
            }
        }
        return .notFound
    }

    private static func plainLines(_ text: String) -> [String] {
        let lines = text.components(separatedBy: .newlines).map { $0.trimmingCharacters(in: .whitespaces) }
        if lines.contains(where: { !$0.isEmpty }) {
            return lines
        }
        return []
    }

    /// Parses LRC text such as "[00:27.93] Listen to the wind blow".
    private static func parseSynced(_ raw: String) -> [LyricLine] {
        var lines: [LyricLine] = []
        for rawLine in raw.components(separatedBy: .newlines) {
            var rest = Substring(rawLine.trimmingCharacters(in: .whitespaces))
            var stamps: [Double] = []
            while rest.hasPrefix("["), let close = rest.firstIndex(of: "]") {
                let tag = String(rest[rest.index(after: rest.startIndex)..<close])
                guard let stamp = parseTimestamp(tag) else {
                    break
                }
                stamps.append(stamp)
                rest = rest[rest.index(after: close)...]
            }
            if stamps.isEmpty {
                continue
            }
            let text = rest.trimmingCharacters(in: .whitespaces)
            for stamp in stamps {
                lines.append(LyricLine(timeMs: stamp, text: text))
            }
        }
        return lines.sorted { $0.timeMs < $1.timeMs }
    }

    /// "01:02.50" or "01:02:50" to milliseconds. Returns nil for tags like "ar:Artist".
    private static func parseTimestamp(_ tag: String) -> Double? {
        let parts = tag.split(separator: ":").map { String($0) }
        if parts.count == 2, let minutes = Double(parts[0]), let seconds = Double(parts[1]) {
            return (minutes * 60 + seconds) * 1000
        }
        if parts.count == 3, let minutes = Double(parts[0]), let seconds = Double(parts[1]), let hundredths = Double(parts[2]) {
            return (minutes * 60 + seconds) * 1000 + hundredths * 10
        }
        return nil
    }

    /// "Song - Remastered 2011" and "Song (feat. X)" become "Song" for a wider search.
    private static func cleanTitle(_ title: String) -> String {
        var text = title
        if let dash = text.range(of: " - ") {
            text = String(text[..<dash.lowerBound])
        }
        text = text.replacingOccurrences(of: "\\s*[\\(\\[][^\\)\\]]*[\\)\\]]", with: "", options: .regularExpression)
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        return trimmed.isEmpty ? title : trimmed
    }
}

// MARK: - Views

/// Replaces the artwork in the player with the lyrics of the current song.
struct LyricsPanel: View {
    @EnvironmentObject private var player: PlayerStore
    @EnvironmentObject private var lyrics: LyricsStore

    var body: some View {
        VStack(spacing: 6) {
            content
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            Text("Lyrics from LRCLIB, a community database")
                .font(.caption2)
                .foregroundStyle(Color.white.opacity(0.45))
        }
        .task(id: player.track?.uri) {
            await lyrics.load(for: player.track)
        }
    }

    @ViewBuilder private var content: some View {
        switch lyrics.state {
        case .idle, .loading:
            ProgressView()
        case .synced(let lines):
            SyncedLyricsView(lines: lines)
        case .plain(let lines):
            PlainLyricsView(lines: lines)
        case .instrumental:
            LyricsMessage(symbol: "pianokeys", text: "This track is instrumental.")
        case .notFound:
            LyricsMessage(symbol: "text.badge.xmark", text: "No lyrics found for this song.")
        case .failed(let text):
            LyricsMessage(symbol: "wifi.exclamationmark", text: text)
        }
    }
}

struct LyricsMessage: View {
    let symbol: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.largeTitle)
            Text(text)
                .font(.subheadline)
                .multilineTextAlignment(.center)
        }
        .foregroundStyle(Color.white.opacity(0.7))
        .padding(24)
    }
}

/// Time-synced lyrics: the current line is bright, and tapping a line jumps to it.
struct SyncedLyricsView: View {
    let lines: [LyricLine]
    @EnvironmentObject private var player: PlayerStore

    private var currentIndex: Int {
        let position = player.progressMs + 300
        var found = -1
        for (index, line) in lines.enumerated() {
            if line.timeMs <= position {
                found = index
            } else {
                break
            }
        }
        return found
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    ForEach(Array(lines.enumerated()), id: \.offset) { index, line in
                        Button {
                            player.seek(toMs: line.timeMs)
                        } label: {
                            Text(line.text.isEmpty ? "♪" : line.text)
                                .font(.title2.weight(.bold))
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .opacity(index == currentIndex ? 1 : 0.4)
                        }
                        .buttonStyle(.plain)
                        .id(index)
                    }
                }
                .padding(.vertical, 28)
            }
            .scrollIndicators(.hidden)
            .onAppear {
                if currentIndex >= 0 {
                    proxy.scrollTo(currentIndex, anchor: .center)
                }
            }
            .onChange(of: currentIndex) { _, newIndex in
                guard newIndex >= 0 else { return }
                withAnimation(.easeInOut(duration: 0.35)) {
                    proxy.scrollTo(newIndex, anchor: .center)
                }
            }
        }
    }
}

struct PlainLyricsView: View {
    let lines: [String]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(Array(lines.enumerated()), id: \.offset) { _, line in
                    Text(line.isEmpty ? " " : line)
                        .font(.title3.weight(.semibold))
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Text("These lyrics aren't time-synced, so they don't follow the song.")
                    .font(.footnote)
                    .foregroundStyle(Color.white.opacity(0.55))
                    .padding(.top, 14)
            }
            .padding(.vertical, 28)
        }
        .scrollIndicators(.hidden)
    }
}
