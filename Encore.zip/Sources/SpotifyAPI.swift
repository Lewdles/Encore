import Combine
import Foundation

enum APIError: LocalizedError {
    case http(status: Int, message: String?, reason: String?)
    case badResponse
    case unreadable(String)

    /// True when Spotify has no device ready to receive a playback command.
    var isNoActiveDevice: Bool {
        if case .http(let status, _, let reason) = self {
            return reason == "NO_ACTIVE_DEVICE" || status == 404
        }
        return false
    }

    /// True when Spotify asks the app to slow down.
    var isRateLimited: Bool {
        if case .http(let status, _, _) = self {
            return status == 429
        }
        return false
    }

    var errorDescription: String? {
        switch self {
        case .badResponse:
            return "Spotify sent an unexpected reply."
        case .unreadable(let detail):
            return "Could not read Spotify's reply (\(detail))."
        case .http(let status, let message, let reason):
            if reason == "PREMIUM_REQUIRED" {
                return "Spotify Premium is required to control playback."
            }
            if status == 429 {
                return "Spotify is rate-limiting requests. Wait a moment and try again."
            }
            if status == 403 {
                return message ?? "Spotify refused this request. Check that your account is listed under User Management in the developer dashboard."
            }
            return message ?? "Spotify returned error \(status)."
        }
    }
}

/// A thin client for the Spotify Web API endpoints still open to Development Mode apps.
@MainActor
final class SpotifyAPI: ObservableObject {
    private let auth: AuthStore
    private let session: URLSession
    private let decoder: JSONDecoder

    init(auth: AuthStore) {
        self.auth = auth
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 15
        self.session = URLSession(configuration: configuration)
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        self.decoder = decoder
    }

    // MARK: Core requests

    @discardableResult
    private func send(_ method: String, _ path: String, query: [String: String] = [:], json: [String: Any]? = nil) async throws -> Data {
        var attempt = 0
        while true {
            attempt += 1
            let token = try await auth.validToken()
            let request = try makeRequest(method, path, query: query, json: json, token: token)
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw APIError.badResponse
            }
            if http.statusCode >= 200 && http.statusCode < 300 {
                return data
            }
            if http.statusCode == 401 && attempt == 1 {
                auth.invalidateAccessToken()
                continue
            }
            let envelope = try? decoder.decode(SPErrorEnvelope.self, from: data)
            throw APIError.http(status: http.statusCode, message: envelope?.error?.message, reason: envelope?.error?.reason)
        }
    }

    private func makeRequest(_ method: String, _ path: String, query: [String: String], json: [String: Any]?, token: String) throws -> URLRequest {
        let address = path.hasPrefix("http") ? path : "https://api.spotify.com/v1" + path
        guard var components = URLComponents(string: address) else {
            throw APIError.badResponse
        }
        if !query.isEmpty {
            var items = components.queryItems ?? []
            for name in query.keys.sorted() {
                items.append(URLQueryItem(name: name, value: query[name]))
            }
            components.queryItems = items
        }
        guard let url = components.url else {
            throw APIError.badResponse
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        if let json {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
        } else if method != "GET" {
            // Spotify expects a Content-Length on PUT/POST even when there is nothing to send.
            request.httpBody = Data()
        }
        return request
    }

    private func get<Value: Decodable>(_ type: Value.Type, _ path: String, query: [String: String] = [:]) async throws -> Value {
        let data = try await send("GET", path, query: query)
        do {
            return try decoder.decode(Value.self, from: data)
        } catch {
            throw APIError.unreadable(String(describing: type))
        }
    }

    /// Follows `next` links and gathers the items of each page.
    private func collect<Item: Decodable & Hashable>(_ type: Item.Type, _ path: String, query: [String: String] = [:], maxPages: Int) async throws -> [Item] {
        var gathered: [Item] = []
        var page = try await get(SPPage<Item>.self, path, query: query)
        gathered.append(contentsOf: page.list)
        var pagesRead = 1
        while let next = page.next, pagesRead < maxPages {
            page = try await get(SPPage<Item>.self, next)
            gathered.append(contentsOf: page.list)
            pagesRead += 1
        }
        return gathered
    }

    private func deviceQuery(_ deviceID: String?) -> [String: String] {
        if let deviceID {
            return ["device_id": deviceID]
        }
        return [:]
    }

    // MARK: Profile and library

    func me() async throws -> SPUser {
        try await get(SPUser.self, "/me")
    }

    func playlists(maxPages: Int) async throws -> [SPPlaylist] {
        try await collect(SPPlaylist.self, "/me/playlists", query: ["limit": "50"], maxPages: maxPages)
    }

    func savedAlbums() async throws -> [SPAlbum] {
        let saved = try await collect(SPSavedAlbum.self, "/me/albums", query: ["limit": "50"], maxPages: 4)
        return saved.compactMap { $0.album }
    }

    func savedTracks(offset: Int) async throws -> SPPage<SPSavedTrack> {
        try await get(SPPage<SPSavedTrack>.self, "/me/tracks", query: ["limit": "50", "offset": String(offset)])
    }

    func followedArtists() async throws -> [SPArtist] {
        let following = try await get(SPFollowing.self, "/me/following", query: ["type": "artist", "limit": "50"])
        return following.artists?.list ?? []
    }

    func topTracks() async throws -> [SPTrack] {
        let page = try await get(SPPage<SPTrack>.self, "/me/top/tracks", query: ["limit": "20", "time_range": "short_term"])
        return page.list
    }

    func topArtists() async throws -> [SPArtist] {
        let page = try await get(SPPage<SPArtist>.self, "/me/top/artists", query: ["limit": "20", "time_range": "medium_term"])
        return page.list
    }

    func recentlyPlayed() async throws -> [SPTrack] {
        let page = try await get(SPPage<SPPlayHistory>.self, "/me/player/recently-played", query: ["limit": "30"])
        return page.list.compactMap { $0.track }
    }

    // MARK: Catalogue

    func album(id: String) async throws -> SPAlbumFull {
        try await get(SPAlbumFull.self, "/albums/" + id)
    }

    func moreAlbumTracks(from next: String) async throws -> [SPTrack] {
        try await collect(SPTrack.self, next, maxPages: 6)
    }

    func artist(id: String) async throws -> SPArtist {
        try await get(SPArtist.self, "/artists/" + id)
    }

    func artistAlbums(id: String) async throws -> [SPAlbum] {
        try await collect(SPAlbum.self, "/artists/" + id + "/albums", query: ["include_groups": "album,single"], maxPages: 3)
    }

    func playlist(id: String) async throws -> SPPlaylist {
        try await get(SPPlaylist.self, "/playlists/" + id)
    }

    func morePlaylistTracks(from next: String) async throws -> [SPTrack] {
        let entries = try await collect(SPPlaylistEntry.self, next, maxPages: 10)
        return entries.compactMap { $0.resolved }
    }

    func search(_ term: String) async throws -> SPSearch {
        // Development Mode apps may ask for at most 10 results per type.
        try await get(SPSearch.self, "/search", query: ["q": term, "type": "track,album,artist,playlist", "limit": "10"])
    }

    // MARK: Player

    func playback() async throws -> SPPlayback? {
        let data = try await send("GET", "/me/player", query: ["additional_types": "track,episode"])
        if data.isEmpty {
            return nil
        }
        return try? decoder.decode(SPPlayback.self, from: data)
    }

    func devices() async throws -> [SPDevice] {
        let list = try await get(SPDeviceList.self, "/me/player/devices")
        return (list.devices ?? []).compactMap { $0 }
    }

    func play(deviceID: String?, body: [String: Any]?) async throws {
        try await send("PUT", "/me/player/play", query: deviceQuery(deviceID), json: body)
    }

    func pause(deviceID: String?) async throws {
        try await send("PUT", "/me/player/pause", query: deviceQuery(deviceID))
    }

    func skipNext(deviceID: String?) async throws {
        try await send("POST", "/me/player/next", query: deviceQuery(deviceID))
    }

    func skipPrevious(deviceID: String?) async throws {
        try await send("POST", "/me/player/previous", query: deviceQuery(deviceID))
    }

    func seek(toMs position: Int, deviceID: String?) async throws {
        var query = deviceQuery(deviceID)
        query["position_ms"] = String(position)
        try await send("PUT", "/me/player/seek", query: query)
    }

    func setShuffle(_ isOn: Bool, deviceID: String?) async throws {
        var query = deviceQuery(deviceID)
        query["state"] = isOn ? "true" : "false"
        try await send("PUT", "/me/player/shuffle", query: query)
    }

    func setRepeat(_ mode: String, deviceID: String?) async throws {
        var query = deviceQuery(deviceID)
        query["state"] = mode
        try await send("PUT", "/me/player/repeat", query: query)
    }

    func transfer(to deviceID: String, play: Bool) async throws {
        let body: [String: Any] = ["device_ids": [deviceID], "play": play]
        try await send("PUT", "/me/player", json: body)
    }

    func addToQueue(uri: String, deviceID: String?) async throws {
        var query = deviceQuery(deviceID)
        query["uri"] = uri
        try await send("POST", "/me/player/queue", query: query)
    }

    func queue() async throws -> SPQueue {
        try await get(SPQueue.self, "/me/player/queue")
    }

    // MARK: Liked items (the 2026 library endpoints take Spotify URIs)

    func isSaved(uri: String) async throws -> Bool {
        let flags = try await get([Bool].self, "/me/library/contains", query: ["uris": uri])
        return flags.first ?? false
    }

    func saveToLibrary(uri: String) async throws {
        try await send("PUT", "/me/library", query: ["uris": uri])
    }

    func removeFromLibrary(uri: String) async throws {
        try await send("DELETE", "/me/library", query: ["uris": uri])
    }
}
