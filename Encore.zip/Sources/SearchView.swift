import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore

    @State private var query: String = ""
    @State private var results: SPSearch?
    @State private var isSearching: Bool = false
    @State private var errorText: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                if let errorText {
                    LoadFailedView(message: errorText) {
                        Task { await runSearch(delayed: false) }
                    }
                } else if trimmedQuery.isEmpty {
                    hint("Search your Spotify catalogue for songs, albums, artists and playlists.")
                } else if results == nil {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding(.top, 60)
                } else if hasNoResults {
                    hint("No results for “" + trimmedQuery + "”.")
                } else {
                    songsSection
                    artistsSection
                    albumsSection
                    playlistsSection
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .navigationTitle("Search")
        .searchable(text: $query, prompt: "Songs, albums, artists, playlists")
        .autocorrectionDisabled()
        .task(id: query) {
            await runSearch(delayed: true)
        }
    }

    // MARK: Result lists

    private var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var foundTracks: [SPTrack] {
        results?.tracks?.list ?? []
    }

    private var foundArtists: [SPArtist] {
        results?.artists?.list ?? []
    }

    private var foundAlbums: [SPAlbum] {
        results?.albums?.list ?? []
    }

    private var foundPlaylists: [SPPlaylist] {
        results?.playlists?.list ?? []
    }

    private var hasNoResults: Bool {
        foundTracks.isEmpty && foundArtists.isEmpty && foundAlbums.isEmpty && foundPlaylists.isEmpty
    }

    private func hint(_ text: String) -> some View {
        Text(text)
            .font(.subheadline)
            .foregroundStyle(Color.secondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 32)
            .padding(.top, 60)
    }

    // MARK: Sections

    @ViewBuilder private var songsSection: some View {
        if !foundTracks.isEmpty {
            VStack(spacing: 6) {
                SectionHeader(title: "Songs")
                VStack(spacing: 0) {
                    ForEach(Array(foundTracks.enumerated()), id: \.offset) { index, track in
                        TrackButton(track: track) {
                            player.play(tracks: foundTracks, startAt: index)
                        }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }

    @ViewBuilder private var artistsSection: some View {
        if !foundArtists.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Artists")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(foundArtists.enumerated()), id: \.offset) { _, artist in
                            if let id = artist.id {
                                NavigationLink(value: Route.artist(id)) {
                                    MediaCard(
                                        title: artist.name ?? "Artist",
                                        subtitle: "",
                                        imageURL: artworkURL(artist.images, minWidth: 300),
                                        width: 120,
                                        isCircle: true
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    @ViewBuilder private var albumsSection: some View {
        if !foundAlbums.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Albums")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(foundAlbums.enumerated()), id: \.offset) { _, album in
                            if let id = album.id {
                                NavigationLink(value: Route.album(id)) {
                                    MediaCard(
                                        title: album.name ?? "Album",
                                        subtitle: (album.artists ?? []).compactMap { $0.name }.joined(separator: ", "),
                                        imageURL: artworkURL(album.images, minWidth: 300)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    @ViewBuilder private var playlistsSection: some View {
        if !foundPlaylists.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Playlists")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(foundPlaylists.enumerated()), id: \.offset) { _, playlist in
                            if let id = playlist.id {
                                NavigationLink(value: Route.playlist(id)) {
                                    MediaCard(
                                        title: playlist.name ?? "Playlist",
                                        subtitle: playlist.owner?.displayName ?? "",
                                        imageURL: artworkURL(playlist.images, minWidth: 300)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    // MARK: Searching

    private func runSearch(delayed: Bool) async {
        let term = trimmedQuery
        guard !term.isEmpty else {
            results = nil
            errorText = nil
            return
        }
        if delayed {
            // Wait for a pause in typing before asking Spotify.
            try? await Task.sleep(nanoseconds: 400_000_000)
            if Task.isCancelled {
                return
            }
        }
        do {
            let found = try await api.search(term)
            if Task.isCancelled {
                return
            }
            results = found
            errorText = nil
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
            }
        }
    }
}
