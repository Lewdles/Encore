import SwiftUI
import UIKit

/// Owns the three long-lived objects of the app.
@MainActor
final class AppModel: ObservableObject {
    let auth: AuthStore
    let api: SpotifyAPI
    let player: PlayerStore
    let lyrics: LyricsStore

    init() {
        let auth = AuthStore()
        let api = SpotifyAPI(auth: auth)
        self.auth = auth
        self.api = api
        self.player = PlayerStore(api: api)
        self.lyrics = LyricsStore()
    }
}

@main
struct EncoreApp: App {
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model.auth)
                .environmentObject(model.api)
                .environmentObject(model.player)
                .environmentObject(model.lyrics)
        }
    }
}

/// Pages that can be pushed inside any tab.
enum Route: Hashable {
    case album(String)
    case playlist(String)
    case artist(String)
    case likedSongs
}

extension View {
    func withRoutes() -> some View {
        navigationDestination(for: Route.self) { route in
            switch route {
            case .album(let id):
                AlbumView(albumID: id)
            case .playlist(let id):
                PlaylistView(playlistID: id)
            case .artist(let id):
                ArtistView(artistID: id)
            case .likedSongs:
                LikedSongsView()
            }
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var auth: AuthStore
    @EnvironmentObject private var player: PlayerStore
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        Group {
            if auth.isLoggedIn {
                MainTabs()
            } else {
                WelcomeView()
            }
        }
        .onAppear {
            if auth.isLoggedIn {
                player.becameActive()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            guard auth.isLoggedIn else { return }
            if newPhase == .active {
                player.becameActive()
            } else if newPhase == .background {
                player.stop()
            }
        }
        .onChange(of: auth.isLoggedIn) { _, loggedIn in
            if loggedIn {
                player.becameActive()
            } else {
                player.reset()
            }
        }
    }
}

struct MainTabs: View {
    @EnvironmentObject private var auth: AuthStore
    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore
    @EnvironmentObject private var lyrics: LyricsStore

    var body: some View {
        TabView {
            page { HomeView() }
                .tabItem { Label("Home", systemImage: "house.fill") }
            page { LibraryView() }
                .tabItem { Label("Library", systemImage: "square.stack.fill") }
            page { SearchView() }
                .tabItem { Label("Search", systemImage: "magnifyingglass") }
        }
        .modifier(ToastLayer())
        .sheet(isPresented: $player.showNowPlaying) {
            NowPlayingView()
                .environmentObject(auth)
                .environmentObject(api)
                .environmentObject(player)
                .environmentObject(lyrics)
        }
    }

    /// Wraps a tab in its own navigation stack and keeps the mini player above the tab bar.
    private func page<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        NavigationStack {
            content()
                .withRoutes()
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            MiniPlayerBar()
        }
    }
}

struct WelcomeView: View {
    @EnvironmentObject private var auth: AuthStore
    @State private var clientID: String = ""
    @State private var didCopy: Bool = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Encore")
                            .font(.largeTitle.bold())
                        Text("A clean player for your Spotify Premium account. You sign in on Spotify's own page, so Encore never sees your password.")
                            .font(.subheadline)
                            .foregroundStyle(Color.secondary)
                    }
                    .padding(.vertical, 6)
                }

                Section {
                    Text("Create an app in the Spotify developer dashboard, tick Web API, and add this redirect URI exactly:")
                        .font(.subheadline)
                    Button {
                        UIPasteboard.general.string = AuthStore.redirectURI
                        didCopy = true
                    } label: {
                        HStack {
                            Text(AuthStore.redirectURI)
                                .font(.callout.monospaced())
                                .foregroundStyle(Color.primary)
                            Spacer()
                            Image(systemName: didCopy ? "checkmark" : "doc.on.doc")
                        }
                    }
                    if let dashboard = URL(string: "https://developer.spotify.com/dashboard") {
                        Link("Open the Spotify developer dashboard", destination: dashboard)
                    }
                } header: {
                    Text("Step 1")
                }

                Section {
                    TextField("Client ID", text: $clientID)
                        .font(.callout.monospaced())
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Step 2")
                } footer: {
                    Text("Paste the Client ID from your app's settings page. No client secret is needed.")
                }

                Section {
                    Button {
                        let entered = clientID
                        Task { await auth.login(clientID: entered) }
                    } label: {
                        HStack {
                            Spacer()
                            if auth.isWorking {
                                ProgressView()
                            } else {
                                Text("Log In with Spotify")
                                    .font(.headline)
                            }
                            Spacer()
                        }
                    }
                    .disabled(auth.isWorking || clientID.trimmingCharacters(in: .whitespaces).isEmpty)
                } footer: {
                    if let message = auth.errorMessage {
                        Text(message)
                            .foregroundStyle(Color.red)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear {
            if clientID.isEmpty {
                clientID = auth.clientID
            }
        }
    }
}
