import SwiftUI

/// The compact player that floats above the tab bar.
struct MiniPlayerBar: View {
    @EnvironmentObject private var player: PlayerStore

    var body: some View {
        if let track = player.track {
            HStack(spacing: 12) {
                Artwork(url: artworkURL(track.artworkImages, minWidth: 64), size: 42, corner: 7)
                VStack(alignment: .leading, spacing: 1) {
                    Text(track.title)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1)
                    Text(track.artistLine)
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Button {
                    player.togglePlayPause()
                } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.title3)
                        .frame(width: 40, height: 40)
                }
                .accessibilityLabel(player.isPlaying ? "Pause" : "Play")
                Button {
                    player.skipNext()
                } label: {
                    Image(systemName: "forward.fill")
                        .font(.body)
                        .frame(width: 36, height: 40)
                }
                .accessibilityLabel("Next track")
            }
            .foregroundStyle(Color.primary)
            .padding(.leading, 8)
            .padding(.trailing, 6)
            .padding(.vertical, 7)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(alignment: .bottom) {
                MiniProgressLine(fraction: fraction)
                    .padding(.horizontal, 14)
            }
            .shadow(color: Color.black.opacity(0.14), radius: 10, x: 0, y: 4)
            .contentShape(Rectangle())
            .onTapGesture {
                player.showNowPlaying = true
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 6)
        }
    }

    private var fraction: Double {
        let duration = player.durationMs
        guard duration > 0 else { return 0 }
        return min(1, max(0, player.progressMs / duration))
    }
}

struct MiniProgressLine: View {
    let fraction: Double

    var body: some View {
        GeometryReader { proxy in
            Capsule()
                .fill(Color.accentColor)
                .frame(width: proxy.size.width * CGFloat(fraction), height: 2)
        }
        .frame(height: 2)
    }
}

/// The full-screen player.
struct NowPlayingView: View {
    @EnvironmentObject private var player: PlayerStore
    @EnvironmentObject private var api: SpotifyAPI
    @Environment(\.dismiss) private var dismiss
    @State private var showDevices: Bool = false
    @State private var showQueue: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            topBar
            Spacer(minLength: 12)
            Artwork(url: artworkURL(player.track?.artworkImages, minWidth: 600), corner: 14)
                .shadow(color: Color.black.opacity(0.45), radius: 24, x: 0, y: 14)
                .padding(.horizontal, 12)
            Spacer(minLength: 20)
            titleRow
            scrubber
                .padding(.top, 18)
            transport
                .padding(.top, 10)
            Spacer(minLength: 12)
            bottomRow
        }
        .padding(.horizontal, 24)
        .padding(.top, 14)
        .padding(.bottom, 12)
        .foregroundStyle(Color.white)
        .tint(Color.white)
        .background {
            NowPlayingBackdrop(url: artworkURL(player.track?.artworkImages, minWidth: 64))
        }
        .environment(\.colorScheme, .dark)
        .modifier(ToastLayer())
        .presentationDragIndicator(.visible)
        .sheet(isPresented: $showDevices) {
            DevicesSheet()
                .environmentObject(player)
        }
        .sheet(isPresented: $showQueue) {
            QueueSheet()
                .environmentObject(player)
                .environmentObject(api)
        }
    }

    private var topBar: some View {
        HStack {
            Button {
                dismiss()
            } label: {
                Image(systemName: "chevron.down")
                    .font(.title3.weight(.semibold))
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("Close player")
            Spacer()
            VStack(spacing: 1) {
                Text("PLAYING ON")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(Color.white.opacity(0.6))
                Text(player.activeDeviceName ?? "No device")
                    .font(.footnote.weight(.semibold))
                    .lineLimit(1)
            }
            Spacer()
            Color.clear
                .frame(width: 44, height: 44)
        }
    }

    private var titleRow: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(player.track?.title ?? "Nothing playing")
                    .font(.title3.weight(.semibold))
                    .lineLimit(1)
                Text(player.track?.artistLine ?? "Pick something to play")
                    .font(.body)
                    .foregroundStyle(Color.white.opacity(0.7))
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            Button {
                player.toggleLike()
            } label: {
                Image(systemName: player.isLiked ? "heart.fill" : "heart")
                    .font(.title2)
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel(player.isLiked ? "Remove from Liked Songs" : "Add to Liked Songs")
        }
    }

    private var scrubber: some View {
        VStack(spacing: 2) {
            Slider(
                value: $player.progressMs,
                in: 0...max(player.durationMs, 1),
                onEditingChanged: { isEditing in
                    if isEditing {
                        player.beginScrub()
                    } else {
                        player.endScrub()
                    }
                }
            )
            HStack {
                Text(formatTime(ms: player.progressMs))
                Spacer()
                Text("-" + formatTime(ms: max(0, player.durationMs - player.progressMs)))
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(Color.white.opacity(0.65))
        }
    }

    private var transport: some View {
        HStack {
            Spacer()
            Button {
                player.skipPrevious()
            } label: {
                Image(systemName: "backward.fill")
                    .font(.system(size: 30))
                    .frame(width: 64, height: 64)
            }
            .accessibilityLabel("Previous track")
            Spacer()
            Button {
                player.togglePlayPause()
            } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 46))
                    .frame(width: 80, height: 80)
            }
            .accessibilityLabel(player.isPlaying ? "Pause" : "Play")
            Spacer()
            Button {
                player.skipNext()
            } label: {
                Image(systemName: "forward.fill")
                    .font(.system(size: 30))
                    .frame(width: 64, height: 64)
            }
            .accessibilityLabel("Next track")
            Spacer()
        }
    }

    private var bottomRow: some View {
        HStack {
            Button {
                player.toggleShuffle()
            } label: {
                ToggleGlyph(symbol: "shuffle", isOn: player.shuffleOn)
            }
            .accessibilityLabel("Shuffle")
            Spacer()
            Button {
                player.cycleRepeat()
            } label: {
                ToggleGlyph(symbol: player.repeatMode == "track" ? "repeat.1" : "repeat", isOn: player.repeatMode != "off")
            }
            .accessibilityLabel("Repeat")
            Spacer()
            Button {
                showDevices = true
            } label: {
                ToggleGlyph(symbol: "airplayaudio", isOn: false)
            }
            .accessibilityLabel("Devices")
            Spacer()
            Button {
                showQueue = true
            } label: {
                ToggleGlyph(symbol: "list.bullet", isOn: false)
            }
            .accessibilityLabel("Up next")
        }
    }
}

struct ToggleGlyph: View {
    let symbol: String
    let isOn: Bool

    var body: some View {
        Image(systemName: symbol)
            .font(.body.weight(.semibold))
            .frame(width: 44, height: 44)
            .background(Color.white.opacity(isOn ? 0.24 : 0), in: Circle())
    }
}

/// A soft, darkened wash of the current artwork.
struct NowPlayingBackdrop: View {
    let url: URL?

    var body: some View {
        Color.black
            .overlay {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    default:
                        Color(red: 0.16, green: 0.15, blue: 0.24)
                    }
                }
                .blur(radius: 60)
                .opacity(0.8)
            }
            .overlay {
                LinearGradient(
                    colors: [Color.black.opacity(0.25), Color.black.opacity(0.7)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
            .clipped()
            .ignoresSafeArea()
    }
}

struct DevicesSheet: View {
    @EnvironmentObject private var player: PlayerStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    if player.devices.isEmpty {
                        Text(player.isLoadingDevices ? "Looking for devices…" : "No devices found. Open Spotify on the device you want to use, then pull down to refresh.")
                            .font(.subheadline)
                            .foregroundStyle(Color.secondary)
                    }
                    ForEach(Array(player.devices.enumerated()), id: \.offset) { _, device in
                        Button {
                            player.transfer(to: device)
                        } label: {
                            DeviceRow(device: device, isCurrent: device.id != nil && device.id == player.activeDeviceID)
                        }
                        .buttonStyle(.plain)
                    }
                } footer: {
                    Text("Music plays through the Spotify app. Encore is the screen and the remote.")
                }
                Section {
                    Button {
                        player.openSpotify()
                    } label: {
                        Label("Open Spotify", systemImage: "arrow.up.forward.app")
                    }
                }
            }
            .navigationTitle("Devices")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .refreshable {
                await player.loadDevices()
            }
            .task {
                await player.loadDevices()
            }
        }
        .presentationDetents([.medium, .large])
    }
}

struct DeviceRow: View {
    let device: SPDevice
    let isCurrent: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.title3)
                .frame(width: 32)
                .foregroundStyle(isCurrent ? Color.accentColor : Color.secondary)
            Text(device.name ?? "Unnamed device")
                .foregroundStyle(isCurrent ? Color.accentColor : Color.primary)
            Spacer()
            if isCurrent {
                Image(systemName: "checkmark")
                    .foregroundStyle(Color.accentColor)
            }
        }
        .contentShape(Rectangle())
    }

    private var symbol: String {
        switch (device.type ?? "").lowercased() {
        case "smartphone":
            return "iphone"
        case "computer":
            return "laptopcomputer"
        case "tablet":
            return "ipad"
        case "tv":
            return "tv"
        case "automobile":
            return "car"
        default:
            return "hifispeaker"
        }
    }
}

struct QueueSheet: View {
    @EnvironmentObject private var player: PlayerStore
    @EnvironmentObject private var api: SpotifyAPI
    @Environment(\.dismiss) private var dismiss
    @State private var upcoming: [SPTrack] = []
    @State private var hasLoaded: Bool = false
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            List {
                if let errorText {
                    Text(errorText)
                        .font(.subheadline)
                        .foregroundStyle(Color.secondary)
                } else if !hasLoaded {
                    HStack {
                        Spacer()
                        ProgressView()
                        Spacer()
                    }
                    .listRowSeparator(.hidden)
                } else if upcoming.isEmpty {
                    Text("Nothing is queued up.")
                        .font(.subheadline)
                        .foregroundStyle(Color.secondary)
                }
                ForEach(Array(upcoming.enumerated()), id: \.offset) { _, track in
                    TrackRow(track: track)
                }
            }
            .listStyle(.plain)
            .navigationTitle("Up Next")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .task {
                await load()
            }
        }
    }

    private func load() async {
        do {
            let queue = try await api.queue()
            upcoming = (queue.queue ?? []).compactMap { $0 }
            errorText = nil
        } catch {
            if isCancellation(error) { return }
            errorText = describe(error)
        }
        hasLoaded = true
    }
}
