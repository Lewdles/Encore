import AuthenticationServices
import Combine
import CryptoKit
import Foundation
import Security
import UIKit

enum AuthError: LocalizedError {
    case notLoggedIn
    case message(String)
    case token(code: String, detail: String?)

    var errorDescription: String? {
        switch self {
        case .notLoggedIn:
            return "You are logged out. Please log in again."
        case .message(let text):
            return text
        case .token(let code, let detail):
            if code == "invalid_client" {
                return "Spotify did not recognise this Client ID. Check it in your developer dashboard."
            }
            if code == "invalid_grant" {
                return "Your Spotify session expired. Please log in again."
            }
            return detail ?? "Spotify login failed (\(code))."
        }
    }
}

/// Stores tokens in the Keychain. Some sideloading setups sign apps without a
/// working Keychain entitlement, so it falls back to app storage if a write fails.
enum TokenVault {
    private static let service = "app.encore.player.tokens"

    private static func fallbackKey(_ key: String) -> String {
        "vault." + key
    }

    private static func baseQuery(_ key: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
    }

    static func save(_ value: String, key: String) {
        let base = baseQuery(key)
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        let status = SecItemAdd(item as CFDictionary, nil)
        if status == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: fallbackKey(key))
        } else {
            UserDefaults.standard.set(value, forKey: fallbackKey(key))
        }
    }

    static func load(key: String) -> String? {
        var query = baseQuery(key)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecSuccess, let data = result as? Data, let text = String(data: data, encoding: .utf8) {
            return text
        }
        return UserDefaults.standard.string(forKey: fallbackKey(key))
    }

    static func delete(key: String) {
        SecItemDelete(baseQuery(key) as CFDictionary)
        UserDefaults.standard.removeObject(forKey: fallbackKey(key))
    }
}

final class AuthPresenter: NSObject, ASWebAuthenticationPresentationContextProviding {
    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let windows = scenes.flatMap { $0.windows }
        if let keyWindow = windows.first(where: { $0.isKeyWindow }) {
            return keyWindow
        }
        if let anyWindow = windows.first {
            return anyWindow
        }
        if let scene = scenes.first {
            return UIWindow(windowScene: scene)
        }
        return ASPresentationAnchor()
    }
}

/// Logs in with Spotify's Authorization Code + PKCE flow. The password is typed
/// on Spotify's own page; this app only ever receives tokens.
@MainActor
final class AuthStore: ObservableObject {
    static let redirectURI = "encore-player://callback"
    private static let callbackScheme = "encore-player"
    private static let clientIDKey = "spotifyClientID"
    private static let scopes = [
        "user-read-playback-state",
        "user-modify-playback-state",
        "user-read-currently-playing",
        "user-library-read",
        "user-library-modify",
        "playlist-read-private",
        "playlist-read-collaborative",
        "user-top-read",
        "user-read-recently-played",
        "user-follow-read",
        "user-read-private"
    ].joined(separator: " ")

    @Published private(set) var clientID: String = ""
    @Published private(set) var isLoggedIn: Bool = false
    @Published private(set) var isWorking: Bool = false
    @Published var errorMessage: String?

    private let presenter: AuthPresenter
    private var accessToken: String?
    private var refreshToken: String?
    private var expiresAt: Date = Date.distantPast
    private var refreshTask: Task<String, Error>?
    private var webSession: ASWebAuthenticationSession?

    init() {
        presenter = AuthPresenter()
        clientID = UserDefaults.standard.string(forKey: AuthStore.clientIDKey) ?? ""
        accessToken = TokenVault.load(key: "access")
        refreshToken = TokenVault.load(key: "refresh")
        if let raw = TokenVault.load(key: "expires"), let seconds = Double(raw) {
            expiresAt = Date(timeIntervalSince1970: seconds)
        }
        isLoggedIn = refreshToken != nil
    }

    // MARK: Login and logout

    func login(clientID newClientID: String) async {
        let trimmed = newClientID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            errorMessage = "Paste your Spotify Client ID first."
            return
        }
        clientID = trimmed
        UserDefaults.standard.set(trimmed, forKey: AuthStore.clientIDKey)
        errorMessage = nil

        let verifier = AuthStore.randomVerifier()
        let state = UUID().uuidString
        var components = URLComponents()
        components.scheme = "https"
        components.host = "accounts.spotify.com"
        components.path = "/authorize"
        components.queryItems = [
            URLQueryItem(name: "client_id", value: trimmed),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: AuthStore.redirectURI),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "code_challenge", value: AuthStore.challenge(for: verifier)),
            URLQueryItem(name: "scope", value: AuthStore.scopes),
            URLQueryItem(name: "state", value: state)
        ]
        guard let url = components.url else {
            errorMessage = "Could not build the Spotify login address."
            return
        }

        isWorking = true
        do {
            let callback = try await runWebLogin(url: url)
            let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
            let returnedError = items.first(where: { $0.name == "error" })?.value
            let returnedState = items.first(where: { $0.name == "state" })?.value
            let returnedCode = items.first(where: { $0.name == "code" })?.value
            if let returnedError {
                throw AuthError.message("Spotify did not approve the login (\(returnedError)).")
            }
            guard returnedState == state, let code = returnedCode else {
                throw AuthError.message("The login reply from Spotify was incomplete. Please try again.")
            }
            let response = try await requestToken([
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": AuthStore.redirectURI,
                "client_id": trimmed,
                "code_verifier": verifier
            ])
            store(response)
        } catch let sessionError as ASWebAuthenticationSessionError {
            if sessionError.code != .canceledLogin {
                errorMessage = sessionError.localizedDescription
            }
        } catch {
            errorMessage = describe(error)
        }
        webSession = nil
        isWorking = false
    }

    func logout() {
        accessToken = nil
        refreshToken = nil
        expiresAt = Date.distantPast
        refreshTask = nil
        TokenVault.delete(key: "access")
        TokenVault.delete(key: "refresh")
        TokenVault.delete(key: "expires")
        isLoggedIn = false
    }

    // MARK: Tokens

    /// Returns an access token that is good for at least another minute, refreshing it when needed.
    func validToken() async throws -> String {
        if let token = accessToken, expiresAt.timeIntervalSinceNow > 60 {
            return token
        }
        if let running = refreshTask {
            return try await running.value
        }
        guard let refresh = refreshToken else {
            throw AuthError.notLoggedIn
        }
        let id = clientID
        let task = Task<String, Error> {
            let response = try await self.requestToken([
                "grant_type": "refresh_token",
                "refresh_token": refresh,
                "client_id": id
            ])
            self.store(response)
            return response.accessToken
        }
        refreshTask = task
        do {
            let token = try await task.value
            refreshTask = nil
            return token
        } catch {
            refreshTask = nil
            if case AuthError.token(let code, _) = error, code == "invalid_grant" {
                // Spotify ends refresh tokens after six months, or when access is revoked.
                errorMessage = "Your Spotify session expired. Please log in again."
                logout()
            }
            throw error
        }
    }

    /// Forces the next request to fetch a fresh access token.
    func invalidateAccessToken() {
        expiresAt = Date.distantPast
    }

    private func store(_ response: TokenResponse) {
        accessToken = response.accessToken
        expiresAt = Date().addingTimeInterval(TimeInterval(response.expiresIn ?? 3600))
        TokenVault.save(response.accessToken, key: "access")
        TokenVault.save(String(expiresAt.timeIntervalSince1970), key: "expires")
        if let newRefresh = response.refreshToken, !newRefresh.isEmpty {
            refreshToken = newRefresh
            TokenVault.save(newRefresh, key: "refresh")
        }
        isLoggedIn = true
    }

    private func requestToken(_ fields: [String: String]) async throws -> TokenResponse {
        guard let url = URL(string: "https://accounts.spotify.com/api/token") else {
            throw AuthError.message("Could not reach Spotify.")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = AuthStore.formEncode(fields)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw AuthError.message("Spotify sent an unexpected reply.")
        }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        if http.statusCode == 200 {
            return try decoder.decode(TokenResponse.self, from: data)
        }
        let body = try? decoder.decode(TokenErrorBody.self, from: data)
        throw AuthError.token(code: body?.error ?? "http_\(http.statusCode)", detail: body?.errorDescription)
    }

    // MARK: Web login sheet

    private func runWebLogin(url: URL) async throws -> URL {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<URL, Error>) in
            let session = ASWebAuthenticationSession(url: url, callbackURLScheme: AuthStore.callbackScheme) { callbackURL, error in
                if let callbackURL {
                    continuation.resume(returning: callbackURL)
                } else if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume(throwing: AuthError.message("The Spotify login did not finish."))
                }
            }
            session.presentationContextProvider = self.presenter
            session.prefersEphemeralWebBrowserSession = false
            self.webSession = session
            session.start()
        }
    }

    // MARK: PKCE helpers

    private static func randomVerifier() -> String {
        let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
        var text = ""
        for _ in 0..<64 {
            let index = Int.random(in: 0..<alphabet.count)
            text.append(alphabet[index])
        }
        return text
    }

    private static func challenge(for verifier: String) -> String {
        let digest = SHA256.hash(data: Data(verifier.utf8))
        let encoded = Data(digest).base64EncodedString()
        return encoded
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    private static func formEncode(_ fields: [String: String]) -> Data {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        var pairs: [String] = []
        for (name, value) in fields {
            let encodedName = name.addingPercentEncoding(withAllowedCharacters: allowed) ?? name
            let encodedValue = value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
            pairs.append(encodedName + "=" + encodedValue)
        }
        return Data(pairs.joined(separator: "&").utf8)
    }
}
