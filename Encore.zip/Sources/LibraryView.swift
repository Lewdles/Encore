import SwiftUI

struct LibraryView: View {
    enum Shelf: String, CaseIterable, Identifiable {
        case playlists = "Playlists"
        case albums = "Albums"
        case artists = "Artists"

        var id: String {
            rawValue
        }
    }

    @EnvironmentObject private var api: SpotifyAPI

    @State private var shelf: Shelf = .playlists
    @State private var playlists: [SPPlaylist] = []
    @State private var albums: [SPAlbum] = []
    @State private var artists: [SPArtist] = []
    @State private var loadedShelves: Set<Shelf> = []
    @State private var isLoading: Bool = false
    @State private var errorText: String?

    var body: some View {
        List {
            NavigationLink(value: Route.likedSongs) {
                LibraryRow(title: "Liked Songs", subtitle: "Your saved tracks", imageURL: nil, symbol: "heart.fill")
            }

            Picker("Section", selection: $shelf) {
                ForEach(Shelf.allCases) { item in
                    Text(item.rawValue).tag(item)
                }
            }
            .pickerStyle(.segmented)
            .listRowSeparator(.hidden)

            shelfRows

            if isLoading {
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                .listRowSeparator(.hidden)
            }

            if let errorText {
                LoadFailedView(message: errorText) {
                    Task { await load(shelf, force: true) }
                }
                .listRowSeparator(.hidden)
            }
        }
        .listStyle(.plain)
        .navigationTitle("Library")
        .refreshable {
            await load(shelf, force: true)
        }
        .task(id: shelf) {
            await load(shelf, force: false)
        }
    }

    @ViewBuilder private var shelfRows: some View {
        switch shelf {
        case .playlists:
            ForEach(Array(playlists.enumerated()), id: \.offset) { _, playlist in
                if let id = playlist.id {
                    NavigationLink(value: Route.playlist(id)) {
                        LibraryRow(
                            title: playlist.name ?? "Playlist",
                            subtitle: playlist.owner?.displayName ?? "Playlist",
                            imageURL: artworkURL(playlist.images, minWidth: 64),
                            symbol: "music.note.list"
                        )
                    }
                }
            }
        case .albums:
            ForEach(Array(albums.enumerated()), id: \.offset) { _, album in
                if let id = album.id {
                    NavigationLink(value: Route.album(id)) {
                        LibraryRow(
                            title: album.name ?? "Album",
                            subtitle: (album.artists ?? []).compactMap { $0.name }.joined(separator: ", "),
                            imageURL: artworkURL(album.images, minWidth: 64),
                            symbol: "square.stack"
                        )
                    }
                }
            }
        case .artists:
            ForEach(Array(artists.enumerated()), id: \.offset) { _, artist in
                if let id = artist.id {
                    NavigationLink(value: Route.artist(id)) {
                        LibraryRow(
                            title: artist.name ?? "Artist",
                            subtitle: "Artist",
                            imageURL: artworkURL(artist.images, minWidth: 64),
                            symbol: "music.mic",
                            isCircle: true
                        )
                    }
                }
            }
        }
    }

    private func load(_ target: Shelf, force: Bool) async {
        if loadedShelves.contains(target) && !force {
            return
        }
        isLoading = true
        errorText = nil
        do {
            switch target {
            case .playlists:
                playlists = try await api.playlists(maxPages: 6)
            case .albums:
                albums = try await api.savedAlbums()
            case .artists:
                artists = try await api.followedArtists()
            }
            loadedShelves.insert(target)
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
            }
        }
        isLoading = false
    }
}

struct LikedSongsView: View {
    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var player: PlayerStore

    @State private var tracks: [SPTrack] = []
    @State private var total: Int = 0
    @State private var hasLoaded: Bool = false
    @State private var isLoading: Bool = false
    @State private var errorText: String?

    var body: some View {
        List {
            if hasLoaded && tracks.isEmpty && errorText == nil {
                Text("Songs you like will appear here.")
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
            }

            ForEach(Array(tracks.enumerated()), id: \.offset) { index, track in
                TrackButton(track: track) {
                    player.play(tracks: tracks, startAt: index)
                }
                .onAppear {
                    if index == tracks.count - 1 {
                        Task { await loadMore() }
                    }
                }
            }

            if isLoading {
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                .listRowSeparator(.hidden)
            }

            if let errorText {
                LoadFailedView(message: errorText) {
                    Task { await loadMore() }
                }
                .listRowSeparator(.hidden)
            }
        }
        .listStyle(.plain)
        .navigationTitle("Liked Songs")
        .task {
            if !hasLoaded {
                await loadMore()
            }
        }
    }

    private func loadMore() async {
        if isLoading {
            return
        }
        if hasLoaded && errorText == nil && tracks.count >= total {
            return
        }
        isLoading = true
        do {
            let page = try await api.savedTracks(offset: tracks.count)
            let fresh = page.list.compactMap { $0.track }
            total = page.total ?? (tracks.count + fresh.count)
            tracks.append(contentsOf: fresh)
            errorText = nil
            hasLoaded = true
        } catch {
            if !isCancellation(error) {
                errorText = describe(error)
                hasLoaded = true
            }
        }
        isLoading = false
    }
}
