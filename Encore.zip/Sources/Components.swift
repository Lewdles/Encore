import SwiftUI
import UIKit

/// Square artwork that loads from the network. Leave `size` empty to fill the available width.
struct Artwork: View {
    let url: URL?
    var size: CGFloat? = nil
    var corner: CGFloat = 8
    var isCircle: Bool = false

    var body: some View {
        Color.clear
            .aspectRatio(1, contentMode: .fit)
            .overlay {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    default:
                        ArtworkPlaceholder()
                    }
                }
            }
            .clipShape(outline)
            .frame(width: size, height: size)
    }

    private var outline: AnyShape {
        if isCircle {
            return AnyShape(Circle())
        }
        return AnyShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
    }
}

struct ArtworkPlaceholder: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemGray5)
            Image(systemName: "music.note")
                .font(.title3)
                .foregroundStyle(Color(uiColor: .systemGray2))
        }
    }
}

struct SymbolTile: View {
    let symbol: String
    let size: CGFloat

    var body: some View {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
            .fill(Color.accentColor.opacity(0.15))
            .frame(width: size, height: size)
            .overlay {
                Image(systemName: symbol)
                    .font(.title3)
                    .foregroundStyle(Color.accentColor)
            }
    }
}

struct SectionHeader: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.title2.bold())
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 20)
    }
}

/// A fixed-width card for horizontal shelves.
struct MediaCard: View {
    let title: String
    let subtitle: String
    let imageURL: URL?
    var width: CGFloat = 150
    var isCircle: Bool = false

    var body: some View {
        VStack(alignment: isCircle ? .center : .leading, spacing: 6) {
            Artwork(url: imageURL, size: width, corner: 10, isCircle: isCircle)
                .shadow(color: Color.black.opacity(0.14), radius: 6, x: 0, y: 3)
            Text(title)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(Color.primary)
                .lineLimit(1)
            if !subtitle.isEmpty {
                Text(subtitle)
                    .font(.footnote)
                    .foregroundStyle(Color.secondary)
                    .lineLimit(1)
            }
        }
        .frame(width: width, alignment: isCircle ? .center : .leading)
    }
}

/// A flexible card for two-column grids.
struct GridCard: View {
    let title: String
    let subtitle: String
    let imageURL: URL?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Artwork(url: imageURL, corner: 10)
                .shadow(color: Color.black.opacity(0.14), radius: 6, x: 0, y: 3)
            Text(title)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(Color.primary)
                .lineLimit(1)
            Text(subtitle)
                .font(.footnote)
                .foregroundStyle(Color.secondary)
                .lineLimit(1)
        }
    }
}

struct LibraryRow: View {
    let title: String
    let subtitle: String
    let imageURL: URL?
    var symbol: String = "music.note"
    var isCircle: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            if imageURL != nil {
                Artwork(url: imageURL, size: 52, corner: 7, isCircle: isCircle)
            } else {
                SymbolTile(symbol: symbol, size: 52)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 2)
    }
}

struct TrackRow: View {
    let track: SPTrack
    var number: Int? = nil
    var showArtwork: Bool = true
    @EnvironmentObject private var player: PlayerStore

    private var isCurrent: Bool {
        guard let uri = track.uri else { return false }
        return player.track?.uri == uri
    }

    var body: some View {
        HStack(spacing: 12) {
            if let number {
                Text(String(number))
                    .font(.subheadline.monospacedDigit())
                    .foregroundStyle(Color.secondary)
                    .frame(width: 26)
            }
            if showArtwork {
                Artwork(url: artworkURL(track.artworkImages, minWidth: 64), size: 48, corner: 6)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(track.title)
                    .font(.body)
                    .foregroundStyle(isCurrent ? Color.accentColor : Color.primary)
                    .lineLimit(1)
                HStack(spacing: 4) {
                    if track.explicit == true {
                        Image(systemName: "e.square.fill")
                            .font(.caption2)
                            .foregroundStyle(Color.secondary)
                    }
                    Text(track.artistLine)
                        .font(.subheadline)
                        .foregroundStyle(Color.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 8)
            trailing
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
    }

    @ViewBuilder private var trailing: some View {
        if isCurrent && player.isPlaying {
            Image(systemName: "waveform")
                .font(.subheadline)
                .foregroundStyle(Color.accentColor)
        } else if let duration = track.durationMs {
            Text(formatTime(ms: Double(duration)))
                .font(.footnote.monospacedDigit())
                .foregroundStyle(Color.secondary)
        }
    }
}

/// A tappable track row with an "Add to Queue" long-press menu.
struct TrackButton: View {
    let track: SPTrack
    var number: Int? = nil
    var showArtwork: Bool = true
    let action: () -> Void
    @EnvironmentObject private var player: PlayerStore

    var body: some View {
        Button(action: action) {
            TrackRow(track: track, number: number, showArtwork: showArtwork)
        }
        .buttonStyle(.plain)
        .disabled(!track.isPlayable)
        .contextMenu {
            if let uri = track.uri {
                Button {
                    player.addToQueue(uri: uri)
                } label: {
                    Label("Add to Queue", systemImage: "text.badge.plus")
                }
            }
        }
    }
}

struct LoadFailedView: View {
    let message: String
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundStyle(Color.secondary)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(Color.secondary)
                .multilineTextAlignment(.center)
            Button("Try Again", action: retry)
                .buttonStyle(.bordered)
        }
        .padding(32)
        .frame(maxWidth: .infinity)
    }
}

/// The large header shared by album and playlist pages.
struct DetailHeader: View {
    let imageURL: URL?
    let title: String
    let subtitle: String
    let caption: String
    let onPlay: () -> Void
    let onShuffle: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Artwork(url: imageURL, size: 232, corner: 12)
                .shadow(color: Color.black.opacity(0.22), radius: 16, x: 0, y: 8)
            VStack(spacing: 4) {
                Text(title)
                    .font(.title2.bold())
                    .multilineTextAlignment(.center)
                if !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.title3)
                        .foregroundStyle(Color.accentColor)
                        .multilineTextAlignment(.center)
                }
                if !caption.isEmpty {
                    Text(caption)
                        .font(.footnote)
                        .foregroundStyle(Color.secondary)
                }
            }
            HStack(spacing: 12) {
                Button(action: onPlay) {
                    Label("Play", systemImage: "play.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)

                Button(action: onShuffle) {
                    Image(systemName: "shuffle")
                        .font(.headline)
                        .frame(width: 30)
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                .accessibilityLabel("Shuffle")
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 18)
    }
}

// MARK: - Toasts

struct ToastView: View {
    let toast: Toast
    let openSpotify: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Text(toast.text)
                .font(.subheadline)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
            if toast.offersSpotify {
                Button("Open Spotify", action: openSpotify)
                    .font(.subheadline.weight(.semibold))
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.capsule)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: Color.black.opacity(0.18), radius: 12, x: 0, y: 6)
    }
}

/// Shows short messages from the player at the top of whatever it is attached to.
struct ToastLayer: ViewModifier {
    @EnvironmentObject private var player: PlayerStore

    func body(content: Content) -> some View {
        content
            .overlay(alignment: .top) {
                if let toast = player.toast {
                    ToastView(toast: toast) {
                        player.openSpotify()
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 6)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .animation(.easeInOut(duration: 0.25), value: player.toast)
    }
}
