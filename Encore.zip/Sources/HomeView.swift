import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var auth: AuthStore
    @EnvironmentObject private var player: PlayerStore

    @State private var recent: [SPTrack] = []
    @State private var topTracks: [SPTrack] = []
    @State private var topArtists: [SPArtist] = []
    @State private var playlists: [SPPlaylist] = []
    @State private var hasLoaded: Bool = false
    @State private var errorText: String?
    @State private var showAccount: Bool = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                if !hasLoaded {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding(.top, 100)
                } else if let errorText {
                    LoadFailedView(message: errorText) {
                        Task { await load() }
                    }
                } else if isEmpty {
                    Text("Play something in Spotify and your recent music will show up here.")
                        .font(.subheadline)
                        .foregroundStyle(Color.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 32)
                        .padding(.top, 80)
                } else {
                    recentSection
                    topTracksSection
                    artistsSection
                    playlistsSection
                }
            }
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .navigationTitle("Home")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showAccount = true
                } label: {
                    Image(systemName: "person.crop.circle")
                }
                .accessibilityLabel("Account")
            }
        }
        .sheet(isPresented: $showAccount) {
            AccountSheet()
                .environmentObject(api)
                .environmentObject(auth)
        }
        .refreshable {
            await load()
        }
        .task {
            if !hasLoaded {
                await load()
            }
        }
    }

    private var isEmpty: Bool {
        recent.isEmpty && topTracks.isEmpty && topArtists.isEmpty && playlists.isEmpty
    }

    // MARK: Sections

    @ViewBuilder private var recentSection: some View {
        if !recent.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Jump Back In")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(recent.enumerated()), id: \.offset) { index, track in
                            Button {
                                player.play(tracks: recent, startAt: index)
                            } label: {
                                MediaCard(
                                    title: track.title,
                                    subtitle: track.artistLine,
                                    imageURL: artworkURL(track.artworkImages, minWidth: 300)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    @ViewBuilder private var topTracksSection: some View {
        if !topTracks.isEmpty {
            VStack(spacing: 6) {
                SectionHeader(title: "On Repeat")
                VStack(spacing: 0) {
                    ForEach(Array(topTracks.prefix(8).enumerated()), id: \.offset) { index, track in
                        TrackButton(track: track) {
                            player.play(tracks: topTracks, startAt: index)
                        }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }

    @ViewBuilder private var artistsSection: some View {
        if !topArtists.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Your Artists")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(topArtists.enumerated()), id: \.offset) { _, artist in
                            if let id = artist.id {
                                NavigationLink(value: Route.artist(id)) {
                                    MediaCard(
                                        title: artist.name ?? "Artist",
                                        subtitle: "",
                                        imageURL: artworkURL(artist.images, minWidth: 300),
                                        width: 120,
                                        isCircle: true
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    @ViewBuilder private var playlistsSection: some View {
        if !playlists.isEmpty {
            VStack(spacing: 12) {
                SectionHeader(title: "Your Playlists")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 14) {
                        ForEach(Array(playlists.enumerated()), id: \.offset) { _, playlist in
                            if let id = playlist.id {
                                NavigationLink(value: Route.playlist(id)) {
                                    MediaCard(
                                        title: playlist.name ?? "Playlist",
                                        subtitle: playlist.owner?.displayName ?? "",
                                        imageURL: artworkURL(playlist.images, minWidth: 300)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
            }
        }
    }

    // MARK: Loading

    private func load() async {
        var firstError: Error?
        var successes = 0

        do {
            let fetched = try await api.recentlyPlayed()
            recent = uniqueTracks(fetched)
            successes += 1
        } catch {
            firstError = firstError ?? error
        }

        do {
            topTracks = try await api.topTracks()
            successes += 1
        } catch {
            firstError = firstError ?? error
        }

        do {
            topArtists = try await api.topArtists()
            successes += 1
        } catch {
            firstError = firstError ?? error
        }

        do {
            playlists = try await api.playlists(maxPages: 1)
            successes += 1
        } catch {
            firstError = firstError ?? error
        }

        if successes == 0, let failure = firstError {
            if isCancellation(failure) {
                return
            }
            errorText = describe(failure)
        } else {
            errorText = nil
        }
        hasLoaded = true
    }

    private func uniqueTracks(_ tracks: [SPTrack]) -> [SPTrack] {
        var seen = Set<String>()
        var result: [SPTrack] = []
        for track in tracks {
            let key = track.uri ?? track.id ?? UUID().uuidString
            if seen.insert(key).inserted {
                result.append(track)
            }
        }
        return result
    }
}

struct AccountSheet: View {
    @EnvironmentObject private var api: SpotifyAPI
    @EnvironmentObject private var auth: AuthStore
    @Environment(\.dismiss) private var dismiss
    @State private var displayName: String = "…"

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    LabeledContent("Signed in as", value: displayName)
                    LabeledContent("Client ID", value: shortClientID)
                } header: {
                    Text("Spotify account")
                }

                Section {
                    Button("Log Out", role: .destructive) {
                        auth.logout()
                        dismiss()
                    }
                } footer: {
                    Text("Encore is a personal remote for your own Spotify Premium account. Music plays through the Spotify app. Spotify and its catalogue belong to Spotify AB; Encore is not affiliated with Spotify.")
                }
            }
            .navigationTitle("Account")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .task {
                let user = try? await api.me()
                displayName = user?.displayName ?? user?.id ?? "Spotify user"
            }
        }
    }

    private var shortClientID: String {
        let id = auth.clientID
        if id.count <= 8 {
            return id
        }
        return String(id.prefix(4)) + "…" + String(id.suffix(4))
    }
}
